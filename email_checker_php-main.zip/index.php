<?php

// db data
$host = "localhost";
$username = "root";
$password = "";
$dbname = "testtask";

// db enter
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // err set
}
catch(PDOException $connect) {
    echo "Ошибка подключения: ". $connect->getMessage();
    exit();
}

// mail
function str_tolist($list) {
    $func_result = explode(";", $list);
    return $func_result;
}

$mail_list = str_tolist("example1@mail.com;example2@mail.com;example3mail.com;example3mail.com;example4@mail.com");
$mail_error_list = [];

foreach ($mail_list as $email) {
    // mail check
    if (preg_match("/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/", $email)) {
        $pdo->prepare("INSERT INTO emails (email) VALUES (?)")->execute([$email]); // enter to db
    }
    else {
        $mail_error_list[] = $email; // incorrect
    }
}

echo "Количество корректных адресов: ".count($mail_list)-count($mail_error_list)."<br>";
echo "Количество некорректных адресов: ".count($mail_error_list)."<br>";

if (count($mail_error_list)!=0){
    
    if (count($mail_error_list) > 1) {
        echo "Список некорректных адресов: ";
        foreach ($mail_error_list as $key => $email) {
            if ($key == count($mail_error_list)-1){ echo $email; }
            else{ echo $email.", "; }
        }
    }
    else {
        echo "Некорректный адрес: ";
        foreach ($mail_error_list as $email) { echo $email; }
    }
}


?>